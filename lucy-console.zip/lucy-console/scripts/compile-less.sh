lessc ./less/styles.less > ./static/less/styles.css
